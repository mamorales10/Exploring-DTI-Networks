import requests

URL1 = "https://www.ebi.ac.uk/Tools/hmmer/download/BD53D4F2-4106-11E8-AF3C-B8A9DBC3747A."
URL2 = "/score?format=xml"

i = 1

while (i <= 227):
    response = requests.get(URL1 + str(i) + URL2)
    file = open('file%i.txt' %i, 'w')
    file.write(response.content)
    file.close()
    i = i + 1


