import requests

URL1 = "https://www.ebi.ac.uk/Tools/hmmer/download/2B181800-41BA-11E8-A973-8A88F75AEC3D."
URL2 = "/score?format=xml"

i = 1

while (i <= 402):
    response = requests.get(URL1 + str(i) + URL2)
    file = open('file%i.txt' %i, 'w')
    file.write(response.content)
    file.close()
    i = i + 1


