import requests

URL1 = "https://www.ebi.ac.uk/Tools/hmmer/download/5E3873BE-41BB-11E8-98FF-0FBEDBC3747A."
URL2 = "/score?format=xml"

i = 1

while (i <= 44):
    response = requests.get(URL1 + str(i) + URL2)
    file = open('file%i.txt' %i, 'w')
    file.write(response.content)
    file.close()
    i = i + 1


